<?php $__env->startSection('content'); ?>
    <h2>Stok Keluar</h2>

    <?php if(session('success')): ?>
        <div class="alert alert-success"><?php echo e(session('success')); ?></div>
    <?php endif; ?>

    <form action="<?php echo e(route('stockout.store')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <div id="entry-container">
            <div class="entry">
                <div>
                    <label for="item_name">Nama Ikan:</label>
                    <select name="entries[0][item_name]" required>
                        <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($item->item_name); ?>"><?php echo e($item->item_name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div>
                    <label for="stock_out_amount">Jumlah Ikan:</label>
                    <input type="number" name="entries[0][stock_out_amount]" min="1" required>
                </div>
                <div>
                    <label for="weight">Berat:</label>
                    <input type="number" name="entries[0][weight]" step="0.01" min="0" required>
                </div>
                <div>
                    <label for="price">Harga:</label>
                    <input type="number" name="entries[0][price]" step="0.01" min="0" required>
                </div>
                <div>
                    <label for="notes">Catatan:</label>
                    <textarea name="entries[0][notes]"></textarea>
                </div>
            </div>
        </div>
        <button type="button" id="add-entry">+</button>
        <button type="submit">Simpan</button>
        <button type="button" id="generate-out-invoice">Print Invoice</button>
    </form>

    <script>
        const entryContainer = document.getElementById('entry-container');
        const addEntryButton = document.getElementById('add-entry');
        let entryIndex = 1;

        addEntryButton.addEventListener('click', () => {
            const newEntry = document.createElement('div');
            newEntry.classList.add('entry');
            newEntry.innerHTML = `
            <div>
                    <label for="item_name">Nama ikan:</label>
                <select name="entries[${entryIndex}][item_name]" required>
                    <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($item->item_name); ?>"><?php echo e($item->item_name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                </div>
                <div>
                    <label for="stock_out_amount">Jumlah Ikan:</label>
                    <input type="number" name="entries[${entryIndex}][stock_out_amount]" min="1" required>
                </div>
                <div>
                    <label for="weight">Berat:</label>
                    <input type="number" name="entries[${entryIndex}][weight]" step="0.01" min="0" required>
                </div>
                <div>
                    <label for="price">Harga:</label>
                    <input type="number" name="entries[${entryIndex}][price]" step="0.01" min="0" required>
                </div>
                <div>
                    <label for="notes">Catatan:</label>
                    <textarea name="entries[${entryIndex}][notes]"></textarea>
                </div>
            `;

            entryContainer.appendChild(newEntry);
            entryIndex++;
        });
        document.querySelector('#generate-out-invoice').addEventListener('click', function() {
            const currentDate = new Date().toLocaleDateString();
            const entryData = [];
            document.querySelectorAll('.entry').forEach((entry, index) => {
                const itemName = entry.querySelector('select[name^="entries["]').value;
                const weight = entry.querySelector('input[name^="entries["][name$="[weight]"]').value;
                const price = entry.querySelector('input[name^="entries["][name$="[price]"]').value;

                entryData.push({
                    entryIndex: index,
                    itemName,
                    weight,
                    price,
                });
            });
            fetch(`<?php echo e(route('pdf.out_invoice')); ?>`, {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>',
                    },
                    body: JSON.stringify({
                        date: currentDate,
                        entryData,
                    }),
                })
                .then(response => response.blob())
                .then(blob => {
                    const pdfUrl = URL.createObjectURL(blob);
                    window.open(pdfUrl, '_blank');
                    URL.revokeObjectURL(pdfUrl);
                })
                .catch(error => {
                    console.error('Error generating PDF:', error);
                });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\KULIAH\PKL\bperkasa\resources\views/stock/out.blade.php ENDPATH**/ ?>