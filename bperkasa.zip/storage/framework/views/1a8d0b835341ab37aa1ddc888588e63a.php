<?php if($content): ?>
    <?php echo $__env->make($content, \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php endif; ?><?php /**PATH D:\KULIAH\PKL\bperkasa\resources\views/home/layouts/content.blade.php ENDPATH**/ ?>