<?php $__env->startSection('content'); ?>
    <h2>Create New Item</h2>

    <?php if(session('success')): ?>
        <div class="alert alert-success">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>

    <form action="<?php echo e(route('newitem.store')); ?>" method="POST">
        <?php echo csrf_field(); ?>

        <div class="form-group">
            <label for="item_name">Nama Ikan    :</label>
            <input type="text" name="item_name" id="item_name" required>
        </div>

        <div class="form-group">
            <label for="stock_amount">Jumlah Ikan   :</label>
            <input type="number" name="stock_amount" id="stock_amount">
        </div>

        <div class="form-group">
            <label for="weight">Berat   :</label>
            <input type="number" name="weight" id="weight" step="0.01" min="0">
        </div>

        <button type="submit">Tambah Item</button>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\KULIAH\PKL\bperkasa\resources\views/newitem/create.blade.php ENDPATH**/ ?>