<?php $__env->startSection('content'); ?>
    <h2>Data Stok Keluar</h2>

    <form action="<?php echo e(route('stockout.search')); ?>" method="GET">
        <label for="date">Cari Tanggal (yyyy-mm-dd):</label>
        <input type="text" id="date" name="date" placeholder="yyyy-mm-dd" required>
        <button type="submit">Cari</button>
    </form>
    <div>
        <button id="pdf-button" class="btn btn-primary">Print PDF</button>
    </div>

    <table class="table">
        <thead>
            <tr>
                <th>Tanggal</th>
                <th>Nama Ikan</th>
                <th>Jumlah Ikan</th>
                <th>Berat</th>
                <th>Harga</th>
                <th>Catatan</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $outgoingLogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $log): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($log->created_at); ?></td>
                    <td><?php echo e($log->item_name); ?></td>
                    <td><?php echo e($log->stock_out_amount); ?></td>
                    <td><?php echo e($log->weight); ?></td>
                    <td><?php echo e($log->price); ?></td>
                    <td><?php echo e($log->notes); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
    <script>
        document.getElementById('pdf-button').addEventListener('click', function () {
            const currentUrl = window.location.href;
            const url = new URL(currentUrl);
            const dateParam = url.searchParams.get('date');
    
            if (dateParam) {
                const encodedDate = encodeURIComponent(dateParam);
                fetch(`<?php echo e(route('pdf.generateOutgoingLogPDF')); ?>?date=${encodedDate}`, {
                    method: 'GET',
                })
                .then(response => response.blob())
                .then(blob => {
                    const pdfUrl = URL.createObjectURL(blob);
                    window.open(pdfUrl, '_blank');
                    URL.revokeObjectURL(pdfUrl);
                })
                .catch(error => {
                    console.error('Error generating PDF:', error);
                });
            } else {
                fetch('<?php echo e(route('pdf.generateOutgoingLogPDF')); ?>', {
                method: 'GET',
            })
            .then(response => response.blob())
            .then(blob => {
                const pdfUrl = URL.createObjectURL(blob);
                window.open(pdfUrl, '_blank');
                URL.revokeObjectURL(pdfUrl);
            })
            .catch(error => {
                console.error('Error generating PDF:', error);
            });
            }
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\KULIAH\PKL\bperkasa\resources\views/stock/outgoing_log.blade.php ENDPATH**/ ?>