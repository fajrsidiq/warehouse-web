<?php $__env->startSection('content'); ?>
    <h2>Data Stok</h2>
    <a href="<?php echo e(route('newitem.create')); ?>" class="button-link">
        <button>Baru</button>
    </a>
    <a href="<?php echo e(route('stock.in')); ?>" class="button-link">
        <button>Stok Masuk</button>
    </a>
    <a href="<?php echo e(route('stock.out')); ?>" class="button-link">
        <button>Stok Keluar</button>
    </a>
        <button type="button" id="pdf-button">print pdf</button>
        
    <table class="table">
        <thead>
            <tr>
                <th>Nama Ikan</th>
                <th>Jumlah Ikan</th>
                <th>Berat</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $stocks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $stock): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($stock->item_name); ?></td>
                    <td><?php echo e($stock->stock_amount); ?></td>
                    <td><?php echo e($stock->weight); ?> kg </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
    <script>
        document.getElementById('pdf-button').addEventListener('click', function() {
            fetch('<?php echo e(route('pdf.current_stock')); ?>', {
                    method: 'GET',
                })
                .then(response => response.blob())
                .then(blob => {
                    const pdfUrl = URL.createObjectURL(blob);
                    window.open(pdfUrl, '_blank');
                    URL.revokeObjectURL(pdfUrl);
                })
                .catch(error => {
                    console.error('Error generating PDF:', error);
                });

        })
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\KULIAH\PKL\bperkasa\resources\views/stock/current.blade.php ENDPATH**/ ?>