<div class="container">
    <div class="text-center mt-5">
        <h4 class="">Jenis Ikan</h4>
        <p>Jenis ikan apa saja yang kami sediakan ?</p>
    </div>
    <div class="row mt-5">
        <div class="col-md-3 my-3">
            <div class="text-center">
                <img src="/img/coldstorage2.jpg" width="100%" alt="">
                <h5><b>Ikan Tuna</b></h5>
                <p>Lorem ipsum dolor sit amet consectetur, adipisicing elit. Impedit, praesentium.</p>
            </div>
        </div>

        <div class="col-md-3 my-3">
            <div class="text-center">
                <i class="fas fa-home fa-3x text-primary"></i>
                <p>Lorem ipsum dolor sit amet consectetur, adipisicing elit. Impedit, praesentium.</p>
            </div>
        </div>

        <div class="col-md-3 my-3" >
            <div class="text-center">
                <i class="fas fa-home fa-3x text-primary"></i>
                <p>Lorem ipsum dolor sit amet consectetur, adipisicing elit. Impedit, praesentium.</p>
            </div>
        </div>

        <div class="col-md-3 my-3">
            <div class="text-center">
                <i class="fas fa-home fa-3x text-primary"></i>
                <p>Lorem ipsum dolor sit amet consectetur, adipisicing elit. Impedit, praesentium.</p>
            </div>
        </div>

        <div class="col-md-3 my-3">
            <div class="text-center">
                <i class="fas fa-home fa-3x text-primary"></i>
                <p>Lorem ipsum dolor sit amet consectetur, adipisicing elit. Impedit, praesentium.</p>
            </div>
        </div>

        <div class="col-md-3 my-3">
            <div class="text-center">
                <i class="fas fa-home fa-3x text-primary"></i>
                <p>Lorem ipsum dolor sit amet consectetur, adipisicing elit. Impedit, praesentium.</p>
            </div>
        </div>

        <div class="col-md-3 my-3">
            <div class="text-center">
                <i class="fas fa-home fa-3x text-primary"></i>
                <p>Lorem ipsum dolor sit amet consectetur, adipisicing elit. Impedit, praesentium.</p>
            </div>
        </div>

        <div class="col-md-3 my-3">
            <div class="text-center">
                <i class="fas fa-home fa-3x text-primary"></i>
                <p>Lorem ipsum dolor sit amet consectetur, adipisicing elit. Impedit, praesentium.</p>
            </div>
        </div>
        
    </div>
</div>
</div>
<?php /**PATH D:\KULIAH\PKL\bperkasa\resources\views/home/services/index.blade.php ENDPATH**/ ?>