<div class="container my-5">
    <div class="text-center">
        <h4 class="">E-Katalog</h4>
        <p>Kabar Seputar Laut Biru Perkasa</p>
    </div>

    <div class="row">
        <div class="col-md-3 my-3">
            <div class="card shadow-sm">
                <div class="wrapper-card-blog">
                    <img src="/img/lautbiruperkasa2.jpg" class="img-card-blog" alt="">
                </div>
                <div class="p-3">
                    <a href="" class="text-decoration-none"><h5>Ikan Laut Segar Cakalang</h5></a>
                    <p>Lorem ipsum dolor sit amet consectetur, adipisicing elit. At, modi?</p>
                    <a href="">Selengkapnya &RightArrow; </a>
                </div>
            </div>
        </div>

        <div class="col-md-3 my-3">
            <div class="card shadow-sm">
                <div class="wrapper-card-blog">
                    <img src="/img/lautbiruperkasa2.jpg" class="img-card-blog" alt="">
                </div>
                <div class="p-3">
                    <a href="" class="text-decoration-none"><h5>Ikan Laut Segar Cakalang</h5></a>
                    <p>Lorem ipsum dolor sit amet consectetur, adipisicing elit. At, modi?</p>
                    <a href="">Selengkapnya &RightArrow; </a>
                </div>
            </div>
        </div>

        <div class="col-md-3 my-3">
            <div class="card shadow-sm">
                <div class="wrapper-card-blog">
                    <img src="/img/lautbiruperkasa2.jpg" class="img-card-blog" alt="">
                </div>
                <div class="p-3">
                    <a href="" class="text-decoration-none"><h5>Ikan Laut Segar Cakalang</h5></a>
                    <p>Lorem ipsum dolor sit amet consectetur, adipisicing elit. At, modi?</p>
                    <a href="">Selengkapnya &RightArrow; </a>
                </div>
            </div>
        </div>

        <div class="col-md-3 my-3">
            <div class="card shadow-sm">
                <div class="wrapper-card-blog">
                    <img src="/img/lautbiruperkasa2.jpg" class="img-card-blog" alt="">
                </div>
                <div class="p-3">
                    <a href="" class="text-decoration-none"><h5>Ikan Laut Segar Cakalang</h5></a>
                    <p>Lorem ipsum dolor sit amet consectetur, adipisicing elit. At, modi?</p>
                    <a href="">Selengkapnya &RightArrow; </a>
                </div>
            </div>
        </div>

        <div class="col-md-3 my-3">
            <div class="card shadow-sm">
                <div class="wrapper-card-blog">
                    <img src="/img/lautbiruperkasa2.jpg" class="img-card-blog" alt="">
                </div>
                <div class="p-3">
                    <a href="" class="text-decoration-none"><h5>Ikan Laut Segar Cakalang</h5></a>
                    <p>Lorem ipsum dolor sit amet consectetur, adipisicing elit. At, modi?</p>
                    <a href="">Selengkapnya &RightArrow; </a>
                </div>
            </div>
        </div>

        <div class="col-md-3 my-3">
            <div class="card shadow-sm">
                <div class="wrapper-card-blog">
                    <img src="/img/lautbiruperkasa2.jpg" class="img-card-blog" alt="">
                </div>
                <div class="p-3">
                    <a href="" class="text-decoration-none"><h5>Ikan Laut Segar Cakalang</h5></a>
                    <p>Lorem ipsum dolor sit amet consectetur, adipisicing elit. At, modi?</p>
                    <a href="">Selengkapnya &RightArrow; </a>
                </div>
            </div>
        </div>

        <div class="col-md-3 my-3">
            <div class="card shadow-sm">
                <div class="wrapper-card-blog">
                    <img src="/img/lautbiruperkasa2.jpg" class="img-card-blog" alt="">
                </div>
                <div class="p-3">
                    <a href="" class="text-decoration-none"><h5>Ikan Laut Segar Cakalang</h5></a>
                    <p>Lorem ipsum dolor sit amet consectetur, adipisicing elit. At, modi?</p>
                    <a href="">Selengkapnya &RightArrow; </a>
                </div>
            </div>
        </div>

        <div class="col-md-3 my-3">
            <div class="card shadow-sm">
                <div class="wrapper-card-blog">
                    <img src="/img/lautbiruperkasa2.jpg" class="img-card-blog" alt="">
                </div>
                <div class="p-3">
                    <a href="" class="text-decoration-none"><h5>Ikan Laut Segar Cakalang</h5></a>
                    <p>Lorem ipsum dolor sit amet consectetur, adipisicing elit. At, modi?</p>
                    <a href="">Selengkapnya &RightArrow; </a>
                </div>
            </div>
        </div>
    </div>
</div><?php /**PATH D:\KULIAH\PKL\bperkasa\resources\views/home/blog/index.blade.php ENDPATH**/ ?>