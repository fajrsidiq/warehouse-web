<?php $__env->startSection('content'); ?>
<style>
    .total-valuation{
        font-size: 20px;
    }
</style>
    <h2>Valuasi Ikan</h2>

    <table class="table">
        <thead>
            <tr>
                <th>Nama Ikan</th>
                <th>Berat (kg)</th>
                <th>Harga</th>
                <th>Valuasi</th>
            </tr>
        </thead>
        <tbody>
            <?php
                $totalValuation = 0;
            ?>

            <?php $__currentLoopData = $stocks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $stock): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($stock->item_name); ?></td>
                    <td><?php echo e($stock->weight); ?> kg</td>
                    <td>
                        <input type="number" step="0.01" name="price" id="price<?php echo e($stock->id); ?>" class="form-control">
                    </td>
                    <td id="valuation<?php echo e($stock->id); ?>">0.00</td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>

    <div style="display: flex; justify-content: flex-end; align-items: center; padding-top: 10px; padding-right: 40px;">
        <h4 style="margin: 0;">Total Valuation:</h4>
        <p id="total-valuation" style="margin: 0; margin-left: 10px; font-size: 20px;">Rp 0.00</p>
    </div>
    
    <button id="calculateValuation" class="btn btn-primary">Hitung Valuasi</button>

    <script>
        function formatMoney(number) {
            return 'Rp ' + number.toFixed(2).replace(/\d(?=(\d{3})+\.)/g, '$&,');
        }

        document.getElementById('calculateValuation').addEventListener('click', function() {
            var totalValuation = 0;

            <?php $__currentLoopData = $stocks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $stock): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                var price<?php echo e($stock->id); ?> = parseFloat(document.getElementById('price<?php echo e($stock->id); ?>').value) || 0;
                var weight<?php echo e($stock->id); ?> = parseFloat(<?php echo e($stock->weight); ?>) || 0;
                var valuation<?php echo e($stock->id); ?> = (price<?php echo e($stock->id); ?> * weight<?php echo e($stock->id); ?>).toFixed(2);
                document.getElementById('valuation<?php echo e($stock->id); ?>').textContent = formatMoney(parseFloat(valuation<?php echo e($stock->id); ?>));
                totalValuation += parseFloat(valuation<?php echo e($stock->id); ?>);
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            document.getElementById('total-valuation').textContent = formatMoney(totalValuation);
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\KULIAH\PKL\bperkasa\resources\views/stock/valuation.blade.php ENDPATH**/ ?>