<!-- resources/views/pdf/incoming_log.blade.php -->
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Data Stok Masuk</title>
    
    <style>
        .pdf-table {
            border-collapse: collapse;
            width: 100%;
        }
    
        .pdf-table th, .pdf-table td {
            border: 1px solid #000;
            padding: 8px;
            text-align: left;
        }
    </style>
    
</head>
<body>
    <h1>Data Stok Masuk</h1>
    <table id="log-table" class="pdf-table">
        <thead>
            <tr>
                <th>Tanggal</th>
                <th>Nama Ikan</th>
                <th>Jumlah Ikan</th>
                <th>Berat</th>
                <th>Harga</th>
                <th>Catatan</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $outgoingLogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $log): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($log->created_at); ?></td>
                    <td><?php echo e($log->item_name); ?></td>
                    <td><?php echo e($log->stock_out_amount); ?></td>
                    <td><?php echo e($log->weight); ?>KG</td>
                    <td>Rp.<?php echo e($log->price); ?></td>
                    <td><?php echo e($log->notes); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</body>
</html>
<?php /**PATH D:\KULIAH\PKL\bperkasa\resources\views/pdf/outgoing_log.blade.php ENDPATH**/ ?>