@if ($content)
    @include($content)
@endif